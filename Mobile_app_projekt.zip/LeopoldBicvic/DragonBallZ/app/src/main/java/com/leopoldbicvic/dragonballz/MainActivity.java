package com.leopoldbicvic.dragonballz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private Button btnscenes,btnsagas,btncharacters;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView=findViewById(R.id.ivDbzLogo);
        btnscenes=findViewById(R.id.btnScenes);
        btnsagas=findViewById(R.id.btnSagas);
        btncharacters=findViewById(R.id.btnCharacters);
        btnscenes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSongsActivity();
            }
        });
        btnsagas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSagasActivity();
            }
        });
        btncharacters.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCharactersActivity();
            }
        });
    }

    public void openCharactersActivity(){
        Intent intent=new Intent(this,Characters.class);
        startActivity(intent);
    }

    public void openSongsActivity(){
        Intent intent=new Intent(this, Scenes.class);
        startActivity(intent);
    }

    public void openSagasActivity(){
        Intent intent=new Intent(this,Sagas.class);
        startActivity(intent);
    }

}
