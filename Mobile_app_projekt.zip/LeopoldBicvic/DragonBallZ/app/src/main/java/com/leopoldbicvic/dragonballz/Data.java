package com.leopoldbicvic.dragonballz;

import android.graphics.drawable.Drawable;

public class Data {
    private int imageURL;
    private String name;

    public Data(String title, int picture){
        name=title;
        imageURL=picture;
    }

    public int getImageURL() {
        return imageURL;
    }

    public String getName() {
        return name;
    }

}
