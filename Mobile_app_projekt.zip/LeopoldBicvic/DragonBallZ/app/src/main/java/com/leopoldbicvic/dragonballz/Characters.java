package com.leopoldbicvic.dragonballz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.TableLayout;

import com.google.android.material.tabs.TabLayout;

public class Characters extends AppCompatActivity {
    private ViewPager myViewPager;
    private TabLayout mTabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_characters);
        initViews();
        setUpPager();
    }

    private void initViews() {
        myViewPager=findViewById(R.id.viewPager);
        mTabLayout=findViewById(R.id.tab);

    }

    private void setUpPager(){
        PagerAdapter pagerAdapter=new PagerAdapter(getSupportFragmentManager());
        myViewPager.setAdapter(pagerAdapter);
        mTabLayout.setupWithViewPager(myViewPager);
    }
}
