package com.leopoldbicvic.dragonballz;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

public class Scenes extends AppCompatActivity {
    VideoView videoView;
    String videoPath;
    MediaController mediaController;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scenes);
        videoView=findViewById(R.id.vvEpisodes);

        videoPath="android.resource://"+getPackageName()+"/"+R.raw.gokussj;
        Uri uri=Uri.parse(videoPath);
        videoView.setVideoURI(uri);

        mediaController=new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);

        videoView.start();
    }


    public void WhenClickedNext(View view) {
        videoPath="android.resource://"+getPackageName()+"/"+R.raw.vegetassj;
        Uri uri=Uri.parse(videoPath);
        videoView.setVideoURI(uri);
        videoView.start();
    }

    public void WhenClickedBack(View view) {
        videoPath="android.resource://"+getPackageName()+"/"+R.raw.gokussj;
        Uri uri=Uri.parse(videoPath);
        videoView.setVideoURI(uri);
        videoView.start();
    }
}
