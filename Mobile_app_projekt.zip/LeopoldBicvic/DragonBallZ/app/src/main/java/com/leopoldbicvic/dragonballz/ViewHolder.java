package com.leopoldbicvic.dragonballz;

import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.CollationElementIterator;


public class ViewHolder extends RecyclerView.ViewHolder {
    private TextView textView;
    private ImageView imageView;
    public ViewHolder(@NonNull View itemView) {
        super(itemView);
        textView=itemView.findViewById(R.id.tvAttribute);
        imageView=itemView.findViewById(R.id.ivAttribute);
    }
    public void setName(String title){
        textView.setText(title);
    }
    public void setImage(int url){
        imageView.setImageResource(url);
    }
}
