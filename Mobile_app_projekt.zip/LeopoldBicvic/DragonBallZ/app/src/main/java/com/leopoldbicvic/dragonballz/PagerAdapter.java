package com.leopoldbicvic.dragonballz;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.Locale;

public class PagerAdapter extends FragmentStatePagerAdapter {
    private static final int NUM_PAGES=4;
    private static final String BASE_NAME="Hero #%d";

    private FragmentOne Goku;
    private FragmentSec Vegeta;
    private FragmentThird Gohan;
    private FragmentFourth Piccolo;

    public PagerAdapter(FragmentManager fm) {
        super(fm);
        Goku=new FragmentOne();
        Vegeta=new FragmentSec();
        Gohan=new FragmentThird();
        Piccolo=new FragmentFourth();
    }

    @Override
    public Fragment getItem(int position) {
        switch(position){
            case 0:
                return Goku;

            case 1:
                return Vegeta;

            case 2:
                return Gohan;

            default:
                return Piccolo;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return String.format(Locale.getDefault(), BASE_NAME, position + 1);
    }

    @Override
    public int getCount() {
        return NUM_PAGES;
    }
}
