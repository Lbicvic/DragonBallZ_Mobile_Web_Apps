package com.leopoldbicvic.dragonballz;

import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<ViewHolder> {
    private List<Data>dataList=new ArrayList<>();
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View cView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_attribute,parent,false);
        return new ViewHolder(cView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.setName(dataList.get(position).getName());
        holder.setImage(dataList.get(position).getImageURL());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public void addData(List<Data> data){
        dataList.clear();
        dataList.addAll(data);
        notifyDataSetChanged();
    }
}
