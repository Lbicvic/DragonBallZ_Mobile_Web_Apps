package com.leopoldbicvic.dragonballz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.XmlResourceParser;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class Sagas extends AppCompatActivity {

    private RecyclerView recycler;
    private RecyclerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sagas);
        setupRecycler();
        setupRecyclerData();
    }
    private void setupRecycler(){
        recycler=findViewById(R.id.recyclerView);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerAdapter();
        recycler.setAdapter(adapter);
    }
    private void setupRecyclerData(){
        List<Data>data=new ArrayList<>();

        Data prvaSaga= new Data("Raditz Saga",R.drawable.raditz );
        Data drugaSaga= new Data("Vegeta Saga",R.drawable.vegeta);
        Data trecaSaga= new Data("Namek Saga",R.drawable.piccolo);
        Data cetvrtaSaga= new Data("Captain Ginyu Saga",R.drawable.cptginyu);
        Data petaSaga= new Data("Frieza Saga",R.drawable.frieza);
        Data sestaSaga= new Data("Garlic Jr. Saga",R.drawable.garlicjr);
        Data sedmaSaga= new Data("Trunks Saga",R.drawable.trunks);
        Data osmaSaga= new Data("Androids Saga",R.drawable.androids);
        Data devetaSaga= new Data("Imperfect Cell Saga",R.drawable.imperfectcell);
        Data desetaSaga= new Data("Perfect Cell Saga",R.drawable.perfectcell);
        Data jedanaestaSaga= new Data("Cell Games Saga",R.drawable.cellgames);
        Data dvanaestaSaga= new Data("Other World Saga",R.drawable.otherworld);
        Data trinaestaSaga= new Data("Great Saiyaman Saga",R.drawable.greatsaiyaman);
        Data cetrnaestaSaga= new Data("World Tournament Saga",R.drawable.worldtournament);
        Data petnaestaSaga= new Data("Babidi Saga",R.drawable.babidi);
        Data sestnaestaSaga= new Data("Majin Buu Saga",R.drawable.majinbuu);
        Data sedamnaestaSaga= new Data("Fuison Saga",R.drawable.fusion);
        Data osamnaestaSaga= new Data("Kid Buu Saga",R.drawable.kidbuu);
        Data devetnaestaSaga= new Data("Peaceful World Saga",R.drawable.peacefullworld);

        data.add(prvaSaga);
        data.add(drugaSaga);
        data.add(trecaSaga);
        data.add(cetvrtaSaga);
        data.add(petaSaga);
        data.add(sestaSaga);
        data.add(sedmaSaga);
        data.add(osmaSaga);
        data.add(devetaSaga);
        data.add(desetaSaga);
        data.add(jedanaestaSaga);
        data.add(dvanaestaSaga);
        data.add(trinaestaSaga);
        data.add(cetrnaestaSaga);
        data.add(petnaestaSaga);
        data.add(sestnaestaSaga);
        data.add(sedamnaestaSaga);
        data.add(osamnaestaSaga);
        data.add(devetnaestaSaga);

        adapter.addData(data);
    }


}
